// yield T when using member Type:
template<typename T>
struct IdentityT {
  using Type = T;
};
